import { useState, useRef, useEffect, type ReactNode } from 'react'

// ── Types ────────────────────────────────────────────────────
type Screen = 'home' | 'article' | 'panel'
type KcsStatus = 'nueva' | 'revision' | 'cubierta'

// ── Inline SVG Icons ─────────────────────────────────────────
type IP = { size?: number; className?: string }

const Ic = {
  User: ({ size = 20, className = '' }: IP) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className={className}>
      <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" /><circle cx="12" cy="7" r="4" />
    </svg>
  ),
  CreditCard: ({ size = 20, className = '' }: IP) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className={className}>
      <rect x="1" y="4" width="22" height="16" rx="2" /><line x1="1" y1="10" x2="23" y2="10" />
    </svg>
  ),
  Package: ({ size = 20, className = '' }: IP) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className={className}>
      <line x1="16.5" y1="9.4" x2="7.5" y2="4.21" />
      <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" />
      <polyline points="3.27 6.96 12 12.01 20.73 6.96" /><line x1="12" y1="22.08" x2="12" y2="12" />
    </svg>
  ),
  RotateCcw: ({ size = 20, className = '' }: IP) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className={className}>
      <polyline points="1 4 1 10 7 10" /><path d="M3.51 15a9 9 0 1 0 .49-3.51" />
    </svg>
  ),
  Shield: ({ size = 20, className = '' }: IP) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className={className}>
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
    </svg>
  ),
  FileText: ({ size = 20, className = '' }: IP) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className={className}>
      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" /><polyline points="14 2 14 8 20 8" /><line x1="16" y1="13" x2="8" y2="13" /><line x1="16" y1="17" x2="8" y2="17" />
    </svg>
  ),
  Search: ({ size = 20, className = '' }: IP) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className={className}>
      <circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" />
    </svg>
  ),
  MessageCircle: ({ size = 20, className = '' }: IP) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className={className}>
      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
    </svg>
  ),
  ChevronRight: ({ size = 16, className = '' }: IP) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className={className}>
      <polyline points="9 18 15 12 9 6" />
    </svg>
  ),
  ChevronDown: ({ size = 16, className = '' }: IP) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className={className}>
      <polyline points="6 9 12 15 18 9" />
    </svg>
  ),
  X: ({ size = 20, className = '' }: IP) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className={className}>
      <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
    </svg>
  ),
  ThumbsUp: ({ size = 18, className = '' }: IP) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className={className}>
      <path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3H14z" />
      <path d="M7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3" />
    </svg>
  ),
  ThumbsDown: ({ size = 18, className = '' }: IP) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className={className}>
      <path d="M10 15v4a3 3 0 0 0 3 3l4-9V2H5.72a2 2 0 0 0-2 1.7l-1.38 9a2 2 0 0 0 2 2.3H10z" />
      <path d="M17 2h2.67A2.31 2.31 0 0 1 22 4v7a2.31 2.31 0 0 1-2.33 2H17" />
    </svg>
  ),
  Send: ({ size = 18, className = '' }: IP) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className={className}>
      <line x1="22" y1="2" x2="11" y2="13" /><polygon points="22 2 15 22 11 13 2 9 22 2" />
    </svg>
  ),
  AlertCircle: ({ size = 16, className = '' }: IP) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className={className}>
      <circle cx="12" cy="12" r="10" /><line x1="12" y1="8" x2="12" y2="12" /><line x1="12" y1="16" x2="12.01" y2="16" />
    </svg>
  ),
  Info: ({ size = 16, className = '' }: IP) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className={className}>
      <circle cx="12" cy="12" r="10" /><line x1="12" y1="16" x2="12" y2="12" /><line x1="12" y1="8" x2="12.01" y2="8" />
    </svg>
  ),
  CheckCircle: ({ size = 16, className = '' }: IP) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className={className}>
      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" /><polyline points="22 4 12 14.01 9 11.01" />
    </svg>
  ),
  Mail: ({ size = 18, className = '' }: IP) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className={className}>
      <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
      <polyline points="22,6 12,13 2,6" />
    </svg>
  ),
  Plus: ({ size = 15, className = '' }: IP) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className={className}>
      <line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" />
    </svg>
  ),
  Clock: ({ size = 13, className = '' }: IP) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className={className}>
      <circle cx="12" cy="12" r="10" /><polyline points="12 6 12 12 16 14" />
    </svg>
  ),
  ArrowLeft: ({ size = 18, className = '' }: IP) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className={className}>
      <line x1="19" y1="12" x2="5" y2="12" /><polyline points="12 19 5 12 12 5" />
    </svg>
  ),
  HelpCircle: ({ size = 20, className = '' }: IP) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className={className}>
      <circle cx="12" cy="12" r="10" /><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" /><line x1="12" y1="17" x2="12.01" y2="17" />
    </svg>
  ),
  BarChart: ({ size = 20, className = '' }: IP) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className={className}>
      <line x1="18" y1="20" x2="18" y2="10" /><line x1="12" y1="20" x2="12" y2="4" /><line x1="6" y1="20" x2="6" y2="14" />
    </svg>
  ),
  Sparkles: ({ size = 16, className = '' }: IP) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className={className}>
      <path d="M12 3l1.5 4.5L18 9l-4.5 1.5L12 15l-1.5-4.5L6 9l4.5-1.5z" />
      <path d="M19 3l.75 2.25L22 6l-2.25.75L19 9l-.75-2.25L16 6l2.25-.75z" />
    </svg>
  ),
  ExternalLink: ({ size = 13, className = '' }: IP) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className={className}>
      <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
      <polyline points="15 3 21 3 21 9" /><line x1="10" y1="14" x2="21" y2="3" />
    </svg>
  ),
  CircleDot: ({ size = 10, className = '' }: IP) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" stroke="none" aria-hidden="true" className={className}>
      <circle cx="12" cy="12" r="8" />
    </svg>
  ),
  Warning: ({ size = 16, className = '' }: IP) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className={className}>
      <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" />
      <line x1="12" y1="9" x2="12" y2="13" /><line x1="12" y1="17" x2="12.01" y2="17" />
    </svg>
  ),
  Eye: ({ size = 15, className = '' }: IP) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className={className}>
      <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" /><circle cx="12" cy="12" r="3" />
    </svg>
  ),
}

// ── Shared: Skip Link ────────────────────────────────────────
function SkipLink() {
  return (
    <a
      href="#main-content"
      className="sr-only focus:not-sr-only focus:fixed focus:top-4 focus:left-4 focus:z-[9999] focus:bg-[#4338ca] focus:text-white focus:px-4 focus:py-2.5 focus:rounded-lg focus:text-sm focus:font-semibold focus:shadow-lg focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-[#4338ca]"
    >
      Saltar al contenido principal
    </a>
  )
}

// ── Shared: Logo ─────────────────────────────────────────────
function Logo() {
  return (
    <div className="flex items-center gap-3">
      <div
        className="w-9 h-9 rounded-lg flex items-center justify-center text-white text-xs font-bold tracking-wide select-none"
        style={{ background: 'var(--acento)' }}
        aria-hidden="true"
      >
        EM
      </div>
      <div className="leading-none">
        <span className="font-bold text-[17px] text-slate-900">[EMPRESA]</span>
        <span className="text-slate-400 font-normal ml-2 text-[15px]">· Ayuda</span>
      </div>
    </div>
  )
}

// ── Shared: Escalation Block ─────────────────────────────────
function EscalationBlock() {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-6 sm:p-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
      <div className="flex items-start gap-4">
        <div className="shrink-0 w-11 h-11 rounded-full bg-indigo-50 flex items-center justify-center">
          <Ic.HelpCircle size={22} className="text-indigo-700" />
        </div>
        <div>
          <p className="font-semibold text-slate-900 text-[15px]">¿No encontraste lo que buscabas?</p>
          <p className="text-slate-500 text-sm mt-0.5">Nuestro equipo está disponible de lunes a viernes, 9:00–18:00 h.</p>
        </div>
      </div>
      <button
        type="button"
        className="shrink-0 inline-flex items-center gap-2 px-5 py-2.5 rounded-lg text-white text-sm font-semibold hover:opacity-90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-[#4338ca] transition-opacity min-h-[44px]"
        style={{ background: 'var(--acento)' }}
      >
        <Ic.Mail size={16} />
        Contactar soporte
      </button>
    </div>
  )
}

// ── Shared: KCS Status Chip ──────────────────────────────────
function KcsChip({ status }: { status: KcsStatus }) {
  const map: Record<KcsStatus, { label: string; icon: ReactNode; cls: string }> = {
    nueva: {
      label: 'Nueva',
      icon: <Ic.CircleDot size={8} className="text-blue-600" />,
      cls: 'bg-blue-50 text-blue-800 border-blue-200',
    },
    revision: {
      label: 'En revisión',
      icon: <Ic.Clock size={11} className="text-amber-700" />,
      cls: 'bg-amber-50 text-amber-800 border-amber-200',
    },
    cubierta: {
      label: 'Cubierta',
      icon: <Ic.CheckCircle size={11} className="text-emerald-700" />,
      cls: 'bg-emerald-50 text-emerald-800 border-emerald-200',
    },
  }
  const { label, icon, cls } = map[status]
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold border ${cls}`}>
      {icon}
      {label}
    </span>
  )
}

// ── Shared: A11y Annotation Box ──────────────────────────────
function A11yAnnotationPanel({ items }: { items: { n: number; text: string }[] }) {
  return (
    <div className="border-t-2 border-amber-300 bg-amber-50 px-4 sm:px-8 py-6" role="note" aria-label="Anotaciones de accesibilidad de esta pantalla">
      <p className="text-xs font-bold text-amber-800 uppercase tracking-widest mb-3 flex items-center gap-2">
        <Ic.Eye size={13} className="text-amber-700" />
        Anotaciones de accesibilidad — referencia de diseño
      </p>
      <ol className="space-y-1.5 list-none p-0">
        {items.map(({ n, text }) => (
          <li key={n} className="flex items-start gap-2.5 text-sm text-amber-900">
            <span className="shrink-0 inline-flex items-center justify-center w-5 h-5 rounded-full bg-amber-300 text-amber-900 text-[10px] font-bold mt-0.5">
              {n}
            </span>
            <span>{text}</span>
          </li>
        ))}
      </ol>
    </div>
  )
}

// ── Shared: Component States Showcase ───────────────────────
function ComponentStatesShowcase() {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-6">
      {/* Button states */}
      <div>
        <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3">Botón — estados</p>
        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-white text-sm font-semibold min-h-[44px] transition-opacity"
            style={{ background: 'var(--acento)' }}
          >
            Normal
          </button>
          <button
            type="button"
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-white text-sm font-semibold min-h-[44px]"
            style={{ background: 'var(--acento-hover)' }}
            tabIndex={-1}
            aria-label="Botón en estado hover (simulado)"
          >
            Hover
          </button>
          <button
            type="button"
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-white text-sm font-semibold min-h-[44px] ring-2 ring-offset-2"
            style={{ background: 'var(--acento)', ringColor: 'var(--acento)' }}
            aria-label="Botón con foco activo (simulado)"
          >
            <span style={{ outline: '2px solid var(--acento)', outlineOffset: '2px', borderRadius: '6px', padding: '0 2px' }}>Foco</span>
          </button>
          <button
            type="button"
            disabled
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-white text-sm font-semibold min-h-[44px] opacity-40 cursor-not-allowed"
            style={{ background: 'var(--acento)' }}
            aria-disabled="true"
          >
            Deshabilitado
          </button>
        </div>
      </div>

      {/* Chips */}
      <div>
        <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3">Chips KCS — tres valores</p>
        <div className="flex flex-wrap gap-2">
          <KcsChip status="nueva" />
          <KcsChip status="revision" />
          <KcsChip status="cubierta" />
        </div>
      </div>

      {/* Error field */}
      <div>
        <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3">Campo — estado de error</p>
        <div className="max-w-xs space-y-1">
          <label htmlFor="demo-email" className="block text-sm font-medium text-slate-700">
            Correo electrónico
          </label>
          <input
            id="demo-email"
            type="email"
            defaultValue="usuario@"
            aria-invalid="true"
            aria-describedby="demo-email-error"
            className="block w-full px-3 py-2 rounded-lg border-2 border-red-500 bg-red-50 text-slate-900 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-red-600 focus-visible:ring-offset-1"
            readOnly
          />
          <p id="demo-email-error" role="alert" className="flex items-center gap-1.5 text-xs text-red-700 font-medium">
            <Ic.AlertCircle size={13} className="shrink-0 text-red-600" />
            <span>Introduce un correo electrónico válido (ej. nombre@dominio.com)</span>
          </p>
        </div>
      </div>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════
// PANTALLA 1 — INICIO
// ═══════════════════════════════════════════════════════════

const CATEGORIES = [
  { id: 'cuenta', label: 'Cuenta', Icon: Ic.User, count: 24, bg: 'bg-indigo-50', fg: 'text-indigo-700' },
  { id: 'pagos', label: 'Pagos', Icon: Ic.CreditCard, count: 18, bg: 'bg-purple-50', fg: 'text-purple-700' },
  { id: 'envios', label: 'Envíos', Icon: Ic.Package, count: 31, bg: 'bg-emerald-50', fg: 'text-emerald-700' },
  { id: 'devoluciones', label: 'Devoluciones', Icon: Ic.RotateCcw, count: 15, bg: 'bg-orange-50', fg: 'text-orange-700' },
  { id: 'seguridad', label: 'Seguridad', Icon: Ic.Shield, count: 11, bg: 'bg-red-50', fg: 'text-red-700' },
  { id: 'facturacion', label: 'Facturación', Icon: Ic.FileText, count: 9, bg: 'bg-amber-50', fg: 'text-amber-700' },
]

const POPULAR_ARTICLES = [
  'Cómo restablecer mi contraseña paso a paso',
  'Plazos de devolución: todo lo que necesitas saber',
  'Seguimiento de pedido en tiempo real',
  'Métodos de pago aceptados y seguridad en transacciones',
  'Cómo actualizar mi dirección de facturación',
]

const HOME_ANNOTATIONS = [
  { n: 1, text: 'Enlace "Saltar al contenido principal" — visible al recibir foco, posición fija top-4/left-4, contraste blanco sobre #4338CA (7.3:1 ✓). role implícito: link.' },
  { n: 2, text: 'Buscador: <label htmlFor="buscar"> visible en blanco sobre fondo índigo. Placeholder complementa, no sustituye la etiqueta. aria-describedby apunta a nota de uso del prototipo.' },
  { n: 3, text: 'Tarjetas de categoría: botones con min-h-[44px] y min-w completa para objetivo táctil ≥44×44 px. aria-label incluye conteo de artículos.' },
  { n: 4, text: 'Jerarquía de encabezados: H1 "Centro de ayuda de [EMPRESA]" → H2 "Explorar por categoría" → H2 "Artículos populares" → H2 "Estados de componentes".' },
  { n: 5, text: 'Botón flotante de chat: posición fija, w-14 h-14 (56×56 px), aria-label explícito, aria-haspopup="dialog". Focus ring 2 px blanco sobre fondo acento.' },
  { n: 6, text: 'Campo de error en showcase: aria-invalid="true", aria-describedby apunta al mensaje de error, que incluye ícono SVG aria-hidden + texto visible (no solo color).' },
  { n: 7, text: 'Bloque de escalamiento: contraste de texto secundario #475569 sobre blanco = 6.8:1 ✓. Botón "Contactar soporte" mín. 44 px de alto.' },
]

function HomeScreen({ onArticle, onChat }: { onArticle: () => void; onChat: () => void }) {
  return (
    <main id="main-content" tabIndex={-1} className="focus:outline-none" aria-label="Centro de ayuda">
      {/* ── Hero / Search ───────────────────────────── */}
      <section
        className="py-16 px-4 text-center"
        style={{ background: 'linear-gradient(160deg, #3730a3 0%, #4338ca 60%, #6366f1 100%)' }}
        aria-labelledby="home-h1"
      >
        <h1 id="home-h1" className="text-3xl sm:text-4xl font-bold text-white mb-2 leading-tight" style={{ fontFamily: "'DM Serif Display', serif" }}>
          Centro de ayuda de [EMPRESA]
        </h1>
        <p className="text-indigo-200 text-lg mb-8">¿En qué podemos ayudarte hoy?</p>

        <div className="max-w-xl mx-auto">
          <label htmlFor="buscar-ayuda" className="block text-indigo-100 text-sm font-medium mb-2 text-left">
            Buscar en el centro de ayuda
          </label>
          <div role="search" className="relative">
            <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
              <Ic.Search size={20} className="text-slate-400" />
            </div>
            <input
              id="buscar-ayuda"
              type="search"
              placeholder="Escribe tu pregunta…"
              readOnly
              aria-label="Buscar en el centro de ayuda"
              aria-describedby="buscar-nota"
              className="w-full pl-12 pr-4 py-3.5 rounded-xl text-slate-900 bg-white text-base shadow-xl focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-indigo-700"
            />
          </div>
          <p id="buscar-nota" className="sr-only">
            Buscador visual del prototipo. Navega usando las categorías y artículos enlazados a continuación.
          </p>
          <p className="mt-2 text-indigo-300 text-xs text-left" aria-hidden="true">
            Prueba: "cómo devolver un pedido", "problema con mi factura"…
          </p>
        </div>
      </section>

      {/* ── Categories ─────────────────────────────── */}
      <section className="max-w-5xl mx-auto px-4 sm:px-6 py-12" aria-labelledby="cat-h2">
        <h2 id="cat-h2" className="text-xl font-semibold text-slate-900 mb-6">Explorar por categoría</h2>
        <ul className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 list-none p-0 m-0">
          {CATEGORIES.map(({ id, label, Icon, count, bg, fg }) => (
            <li key={id}>
              <button
                type="button"
                onClick={onArticle}
                className="w-full group flex flex-col items-center gap-3 p-4 rounded-xl bg-white border border-slate-200 hover:border-indigo-300 hover:shadow-md hover:shadow-indigo-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#4338ca] focus-visible:ring-offset-2 transition-all cursor-pointer min-h-[120px] justify-center"
                aria-label={`Categoría ${label} — ${count} artículos`}
              >
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${bg} ${fg} transition-transform group-hover:scale-110`}>
                  <Icon size={22} />
                </div>
                <div className="text-center">
                  <p className="font-semibold text-slate-900 text-sm leading-snug">{label}</p>
                  <p className="text-xs text-slate-400 mt-0.5">{count} artículos</p>
                </div>
              </button>
            </li>
          ))}
        </ul>
      </section>

      {/* ── Popular Articles + Component States ────── */}
      <div className="max-w-5xl mx-auto px-4 sm:px-6 pb-10 grid sm:grid-cols-2 gap-8">
        <section aria-labelledby="pop-h2">
          <h2 id="pop-h2" className="text-xl font-semibold text-slate-900 mb-4">Artículos populares</h2>
          <ul className="space-y-1 list-none p-0 m-0">
            {POPULAR_ARTICLES.map((title, i) => (
              <li key={i}>
                <button
                  type="button"
                  onClick={onArticle}
                  className="w-full flex items-center gap-2.5 px-3 py-3 rounded-lg text-left text-slate-700 hover:text-indigo-700 hover:bg-indigo-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#4338ca] focus-visible:ring-offset-1 transition-colors group min-h-[44px]"
                >
                  <Ic.ChevronRight size={15} className="shrink-0 text-indigo-300 group-hover:translate-x-0.5 transition-transform" />
                  <span className="text-sm font-medium">{title}</span>
                </button>
              </li>
            ))}
          </ul>
        </section>

        <section aria-labelledby="states-h2">
          <h2 id="states-h2" className="text-xl font-semibold text-slate-900 mb-4 flex items-center gap-2">
            Estados de componentes
            <span className="text-[10px] font-normal text-slate-400 bg-slate-100 px-2 py-0.5 rounded-full tracking-wide">referencia de diseño</span>
          </h2>
          <ComponentStatesShowcase />
        </section>
      </div>

      {/* ── Escalation ─────────────────────────────── */}
      <div className="max-w-5xl mx-auto px-4 sm:px-6 pb-16">
        <EscalationBlock />
      </div>

      <A11yAnnotationPanel items={HOME_ANNOTATIONS} />
    </main>
  )
}

// ═══════════════════════════════════════════════════════════
// PANTALLA 2 — ARTÍCULO
// ═══════════════════════════════════════════════════════════

function Accordion({ q, a }: { q: string; a: string }) {
  const [open, setOpen] = useState(false)
  const id = `faq-${q.slice(0, 10).replace(/\s/g, '-')}`

  return (
    <div className="border border-slate-200 rounded-xl overflow-hidden">
      <h3>
        <button
          type="button"
          onClick={() => setOpen(o => !o)}
          aria-expanded={open}
          aria-controls={`${id}-panel`}
          id={`${id}-btn`}
          className="w-full flex items-center justify-between gap-3 px-5 py-4 text-left bg-white hover:bg-slate-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-[#4338ca] transition-colors min-h-[56px]"
        >
          <span className="font-medium text-slate-900 text-[15px] leading-snug">{q}</span>
          <Ic.ChevronDown size={18} className={`shrink-0 text-slate-400 transition-transform ${open ? 'rotate-180' : ''}`} />
        </button>
      </h3>
      <div
        id={`${id}-panel`}
        role="region"
        aria-labelledby={`${id}-btn`}
        hidden={!open}
        className="px-5 pb-5 pt-2 bg-slate-50 text-slate-700 text-sm leading-relaxed"
      >
        {a}
      </div>
    </div>
  )
}

const ARTICLE_ANNOTATIONS = [
  { n: 1, text: 'Breadcrumb: nav aria-label="Ruta de navegación". Separadores ">" aria-hidden. Enlace activo con aria-current="page".' },
  { n: 2, text: 'H1 único por pantalla. Fecha como <time datetime="2026-07-15"> para semántica correcta.' },
  { n: 3, text: 'HowTo: ol role="list" con pasos numerados. Cada paso es un <li> con número visible como aria-hidden (el texto completo lo comunica solo).' },
  { n: 4, text: 'Acordeón FAQ: cada pregunta es un <button> dentro de <h3>. aria-expanded / aria-controls enlaza al panel. Panel con role="region" + aria-labelledby.' },
  { n: 5, text: 'Botones "Sí / No" de valoración: min-h-[44px] mín. 44 px, aria-pressed para estado. Respuesta positiva comunicada con texto + ícono de confirmación (no solo color verde).' },
  { n: 6, text: 'Artículos relacionados: lista de navegación con role="list", cada enlace describe destino. Contraste del texto #4338CA sobre blanco = 7.3:1 ✓.' },
]

function ArticleScreen({ onHome }: { onHome: () => void }) {
  const [voted, setVoted] = useState<'si' | 'no' | null>(null)

  return (
    <main id="main-content" tabIndex={-1} className="focus:outline-none">
      {/* ── Breadcrumb ─────────────────────────────── */}
      <div className="border-b border-slate-100 bg-white">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 py-3">
          <nav aria-label="Ruta de navegación">
            <ol className="flex items-center gap-1.5 text-sm text-slate-500 list-none p-0 m-0 flex-wrap">
              <li>
                <button
                  type="button"
                  onClick={onHome}
                  className="text-indigo-700 hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#4338ca] focus-visible:ring-offset-1 rounded"
                >
                  Ayuda
                </button>
              </li>
              <li aria-hidden="true" className="text-slate-300">›</li>
              <li>
                <button
                  type="button"
                  onClick={onHome}
                  className="text-indigo-700 hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#4338ca] focus-visible:ring-offset-1 rounded"
                >
                  Envíos
                </button>
              </li>
              <li aria-hidden="true" className="text-slate-300">›</li>
              <li aria-current="page" className="text-slate-600 font-medium truncate max-w-[200px]">
                Actualizar tu dirección de envío
              </li>
            </ol>
          </nav>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-10">
        {/* ── Header ─────────────────────────────────── */}
        <header className="mb-8">
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 leading-tight mb-3" style={{ fontFamily: "'DM Serif Display', serif" }}>
            Cómo actualizar tu dirección de envío
          </h1>
          <div className="flex items-center gap-3 text-slate-400 text-sm flex-wrap">
            <div className="flex items-center gap-1.5">
              <Ic.Clock size={13} />
              <span>
                Actualizado el{' '}
                <time dateTime="2026-07-15">15 de julio de 2026</time>
              </span>
            </div>
            <span aria-hidden="true">·</span>
            <span>Lectura estimada: 3 min</span>
          </div>
        </header>

        {/* ── Body ───────────────────────────────────── */}
        <article className="prose-article space-y-6 text-slate-700 text-[16px] leading-relaxed">
          <p>
            Mantener tu dirección de envío actualizada es fundamental para garantizar que tus pedidos lleguen al lugar correcto. En [EMPRESA] puedes cambiarla en cualquier momento desde tu panel de cuenta, siempre que el pedido no haya salido aún del almacén.
          </p>
          <p>
            Si el pedido ya está en tránsito, deberás ponerte en contacto con nuestro equipo de soporte antes de las <strong>12:00 h del día siguiente al envío</strong>. Pasado ese plazo, la redirección dependerá de la empresa transportista y no podemos garantizarla.
          </p>

          {/* ── HowTo Steps ──────────────────────────── */}
          <div className="rounded-2xl border border-indigo-100 bg-indigo-50/50 p-5 sm:p-6">
            <div className="flex items-center gap-2 mb-5">
              <div className="w-7 h-7 rounded-lg bg-indigo-700 flex items-center justify-center shrink-0">
                <Ic.FileText size={14} className="text-white" />
              </div>
              <h2 className="font-bold text-slate-900 text-base">Cómo cambiar tu dirección de envío</h2>
            </div>
            <ol className="space-y-4 list-none p-0 m-0" role="list" aria-label="Pasos para cambiar tu dirección de envío">
              {[
                { n: 1, title: 'Accede a tu cuenta', desc: 'Inicia sesión en [EMPRESA] con tu correo y contraseña. Si no recuerdas tu contraseña, usa el enlace "¿Olvidaste tu contraseña?" en la página de acceso.' },
                { n: 2, title: 'Ve a Configuración → Direcciones', desc: 'En el menú superior derecho haz clic en tu avatar y selecciona "Mi cuenta". Luego ve a la pestaña "Direcciones guardadas".' },
                { n: 3, title: 'Edita o añade una dirección', desc: 'Haz clic en "Editar" junto a la dirección que quieres modificar, o en "Añadir nueva dirección" para registrar una diferente.' },
                { n: 4, title: 'Guarda los cambios', desc: 'Completa los campos requeridos y pulsa "Guardar dirección". El sistema la asignará automáticamente a tus próximos pedidos.' },
              ].map(({ n, title, desc }) => (
                <li key={n} className="flex items-start gap-4">
                  <span
                    aria-hidden="true"
                    className="shrink-0 w-8 h-8 rounded-full bg-indigo-700 text-white text-sm font-bold flex items-center justify-center mt-0.5"
                  >
                    {n}
                  </span>
                  <div>
                    <p className="font-semibold text-slate-900 text-[15px] leading-snug">{title}</p>
                    <p className="text-slate-600 text-sm mt-1 leading-relaxed">{desc}</p>
                  </div>
                </li>
              ))}
            </ol>
          </div>

          {/* ── Info callout ─────────────────────────── */}
          <div role="note" className="flex items-start gap-3 p-4 rounded-xl border border-sky-200 bg-sky-50">
            <Ic.Info size={17} className="shrink-0 text-sky-700 mt-0.5" />
            <p className="text-sm text-sky-900">
              <strong>Información:</strong> Los cambios de dirección solo aplican a pedidos futuros. Si ya has realizado un pedido y necesitas cambiar la dirección, contacta soporte lo antes posible.
            </p>
          </div>

          {/* ── FAQ Accordion ────────────────────────── */}
          <div>
            <h2 className="font-bold text-slate-900 text-lg mb-4 flex items-center gap-2">
              <Ic.HelpCircle size={18} className="text-indigo-600" />
              Preguntas frecuentes
            </h2>
            <div className="space-y-3">
              <Accordion
                q="¿Puedo tener varias direcciones de envío guardadas?"
                a="Sí. Puedes guardar hasta 5 direcciones distintas en tu cuenta. Durante el proceso de compra podrás elegir cuál usar para cada pedido. La dirección marcada como 'predeterminada' se seleccionará automáticamente, pero puedes cambiarla en cualquier paso del proceso de pago."
              />
              <Accordion
                q="¿Qué ocurre si introduzco una dirección incorrecta y el pedido ya salió?"
                a="Si el pedido ya está en tránsito, contacta inmediatamente con nuestro equipo de soporte a través del chat o por correo. Intentaremos coordinar con la empresa transportista una redirección, aunque no siempre es posible una vez que el paquete está en reparto. En ese caso, el paquete puede devolverse al remitente y reenviarlo sin coste adicional."
              />
            </div>
          </div>
        </article>

        {/* ── ¿Te resultó útil? ──────────────────────── */}
        <div className="mt-10 pt-8 border-t border-slate-100">
          <h2 className="font-semibold text-slate-900 text-base mb-4">¿Te resultó útil este artículo?</h2>
          {voted === null ? (
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setVoted('si')}
                aria-pressed={false}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg border border-slate-200 bg-white text-slate-700 text-sm font-medium hover:border-emerald-400 hover:text-emerald-700 hover:bg-emerald-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#4338ca] focus-visible:ring-offset-1 transition-colors min-h-[44px]"
              >
                <Ic.ThumbsUp size={16} />
                Sí, me ayudó
              </button>
              <button
                type="button"
                onClick={() => setVoted('no')}
                aria-pressed={false}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg border border-slate-200 bg-white text-slate-700 text-sm font-medium hover:border-red-300 hover:text-red-700 hover:bg-red-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#4338ca] focus-visible:ring-offset-1 transition-colors min-h-[44px]"
              >
                <Ic.ThumbsDown size={16} />
                No del todo
              </button>
            </div>
          ) : voted === 'si' ? (
            <div role="status" className="inline-flex items-center gap-2 text-emerald-700 bg-emerald-50 border border-emerald-200 px-4 py-2.5 rounded-lg text-sm font-medium">
              <Ic.CheckCircle size={16} className="text-emerald-600" />
              <span>¡Gracias! Tu valoración nos ayuda a mejorar.</span>
            </div>
          ) : (
            <div role="status" className="inline-flex items-center gap-2 text-amber-800 bg-amber-50 border border-amber-200 px-4 py-2.5 rounded-lg text-sm font-medium">
              <Ic.Info size={16} className="text-amber-600" />
              <span>Entendido. Considera contactar soporte si necesitas más ayuda.</span>
            </div>
          )}
        </div>

        {/* ── Related Articles ───────────────────────── */}
        <div className="mt-8 pt-8 border-t border-slate-100">
          <h2 className="font-semibold text-slate-900 text-base mb-4">Artículos relacionados</h2>
          <ul className="space-y-2 list-none p-0 m-0">
            {[
              'Seguimiento de tu pedido en tiempo real',
              'Plazos y condiciones de devolución',
              'Cómo cambiar el método de pago de un pedido activo',
            ].map((t, i) => (
              <li key={i}>
                <button
                  type="button"
                  className="flex items-center gap-2.5 text-sm text-indigo-700 hover:text-indigo-900 hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#4338ca] focus-visible:ring-offset-1 rounded min-h-[36px]"
                >
                  <Ic.ChevronRight size={14} className="text-indigo-400 shrink-0" />
                  {t}
                </button>
              </li>
            ))}
          </ul>
        </div>

        {/* ── Escalation ─────────────────────────────── */}
        <div className="mt-10">
          <EscalationBlock />
        </div>
      </div>

      <A11yAnnotationPanel items={ARTICLE_ANNOTATIONS} />
    </main>
  )
}

// ═══════════════════════════════════════════════════════════
// PANTALLA 3 — CHATBOT WIDGET
// ═══════════════════════════════════════════════════════════

const CHAT_ANNOTATIONS = [
  { n: 1, text: 'Dialog: role="dialog" aria-modal="true" aria-labelledby apunta al título del panel. Al abrir, foco se mueve al botón de cierre (useEffect + ref).' },
  { n: 2, text: 'Mensajes: el contenedor tiene aria-live="polite" aria-atomic="false". Cada mensaje nuevo se anuncia a lectores de pantalla sin interrumpir.' },
  { n: 3, text: 'Fuentes numeradas [1][2]: los superíndices usan <sup> con aria-label="Fuente 1" para que los lectores de pantalla los anuncien correctamente.' },
  { n: 4, text: 'Campo de entrada: <label> visible asociado con htmlFor. aria-describedby apunta a la nota sobre generación de IA.' },
  { n: 5, text: 'Botón de cierre: texto visible + aria-label descriptivo. 44×44 px mín. Operable con Escape (keydown handler en el dialog).' },
  { n: 6, text: 'Botón de envío: aria-label="Enviar mensaje" ya que el ícono solo no comunica la acción. Deshabilitado cuando el campo está vacío (prototipo: siempre activo).' },
]

interface ChatWidgetProps {
  onClose: () => void
}

function ChatWidget({ onClose }: ChatWidgetProps) {
  const closeRef = useRef<HTMLButtonElement>(null)

  useEffect(() => {
    closeRef.current?.focus()
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
    }
    document.addEventListener('keydown', handleKey)
    return () => document.removeEventListener('keydown', handleKey)
  }, [onClose])

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 z-40 bg-slate-900/40 backdrop-blur-sm"
        aria-hidden="true"
        onClick={onClose}
      />

      {/* Widget */}
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="chat-titulo"
        className="fixed bottom-6 right-6 z-50 w-[360px] max-w-[calc(100vw-3rem)] bg-white rounded-2xl shadow-2xl flex flex-col overflow-hidden border border-slate-200"
        style={{ maxHeight: 'min(600px, calc(100vh - 3rem))' }}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-slate-100" style={{ background: 'var(--acento)' }}>
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
              <Ic.Sparkles size={15} className="text-white" />
            </div>
            <div>
              <h2 id="chat-titulo" className="text-white font-semibold text-sm leading-none">Asistente virtual</h2>
              <p className="text-indigo-200 text-[11px] mt-0.5">Responde 24/7 · Cita fuentes</p>
            </div>
          </div>
          <button
            ref={closeRef}
            type="button"
            onClick={onClose}
            aria-label="Cerrar asistente virtual"
            className="w-8 h-8 rounded-lg flex items-center justify-center text-white/80 hover:text-white hover:bg-white/20 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white transition-colors"
          >
            <Ic.X size={18} />
          </button>
        </div>

        {/* Messages */}
        <div
          className="flex-1 overflow-y-auto px-4 py-4 space-y-4 min-h-0"
          aria-live="polite"
          aria-atomic="false"
          aria-label="Conversación con el asistente"
        >
          {/* Bot greeting */}
          <div className="flex items-start gap-2.5">
            <div className="shrink-0 w-7 h-7 rounded-full bg-indigo-100 flex items-center justify-center mt-0.5">
              <Ic.Sparkles size={13} className="text-indigo-700" />
            </div>
            <div className="bg-slate-50 rounded-2xl rounded-tl-none px-3.5 py-2.5 max-w-[85%]">
              <p className="text-slate-700 text-sm leading-relaxed">
                Hola, soy el asistente de [EMPRESA]. Puedo ayudarte con preguntas sobre tu cuenta, pedidos, devoluciones y más. ¿En qué puedo ayudarte?
              </p>
            </div>
          </div>

          {/* User message 1 */}
          <div className="flex justify-end">
            <div className="rounded-2xl rounded-tr-none px-3.5 py-2.5 max-w-[85%] text-white text-sm" style={{ background: 'var(--acento)' }}>
              ¿Cómo puedo iniciar una devolución?
            </div>
          </div>

          {/* Bot response 1 — with citations */}
          <div className="flex items-start gap-2.5">
            <div className="shrink-0 w-7 h-7 rounded-full bg-indigo-100 flex items-center justify-center mt-0.5">
              <Ic.Sparkles size={13} className="text-indigo-700" />
            </div>
            <div className="space-y-2 max-w-[85%]">
              <div className="bg-slate-50 rounded-2xl rounded-tl-none px-3.5 py-2.5">
                <p className="text-slate-700 text-sm leading-relaxed">
                  Para iniciar una devolución tienes un plazo de <strong>30 días naturales</strong> desde la fecha de recepción.
                  <sup>
                    <a
                      href="#fuente-1"
                      aria-label="Fuente 1"
                      className="text-indigo-600 hover:text-indigo-800 font-bold ml-0.5 text-[11px] focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#4338ca] rounded"
                    >[1]</a>
                  </sup>{' '}
                  El producto debe estar en su estado original, sin usar y con el embalaje intacto.
                  <sup>
                    <a
                      href="#fuente-2"
                      aria-label="Fuente 2"
                      className="text-indigo-600 hover:text-indigo-800 font-bold ml-0.5 text-[11px] focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#4338ca] rounded"
                    >[2]</a>
                  </sup>{' '}
                  Ve a <em>Mi cuenta → Pedidos → Solicitar devolución</em> y sigue los pasos indicados.
                </p>
              </div>

              {/* Sources block */}
              <div id="fuente-1" className="bg-white border border-slate-200 rounded-xl px-3 py-2.5 space-y-1.5">
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Fuentes</p>
                <a
                  href="#"
                  className="flex items-start gap-1.5 text-[12px] text-indigo-700 hover:text-indigo-900 hover:underline focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#4338ca] rounded leading-snug"
                >
                  <Ic.ExternalLink size={11} className="shrink-0 mt-0.5" />
                  <span id="fuente-2">
                    <strong>[1]</strong> Política de devoluciones — ayuda.empresa.com/devoluciones/politica
                  </span>
                </a>
                <a
                  href="#"
                  className="flex items-start gap-1.5 text-[12px] text-indigo-700 hover:text-indigo-900 hover:underline focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#4338ca] rounded leading-snug"
                >
                  <Ic.ExternalLink size={11} className="shrink-0 mt-0.5" />
                  <span>
                    <strong>[2]</strong> Condiciones del estado del producto — ayuda.empresa.com/devoluciones/condiciones
                  </span>
                </a>
              </div>
            </div>
          </div>

          {/* User message 2 */}
          <div className="flex justify-end">
            <div className="rounded-2xl rounded-tr-none px-3.5 py-2.5 max-w-[85%] text-white text-sm" style={{ background: 'var(--acento)' }}>
              ¿Puedo devolver software descargado digitalmente?
            </div>
          </div>

          {/* Bot response 2 — not found */}
          <div className="flex items-start gap-2.5">
            <div className="shrink-0 w-7 h-7 rounded-full bg-indigo-100 flex items-center justify-center mt-0.5">
              <Ic.Sparkles size={13} className="text-indigo-700" />
            </div>
            <div className="space-y-2 max-w-[85%]">
              <div className="bg-amber-50 border border-amber-200 rounded-2xl rounded-tl-none px-3.5 py-2.5">
                <div className="flex items-center gap-1.5 mb-1.5">
                  <Ic.Warning size={13} className="text-amber-600 shrink-0" />
                  <p className="text-amber-800 text-[11px] font-semibold">No encontrado en la base de conocimiento</p>
                </div>
                <p className="text-slate-700 text-sm leading-relaxed">
                  No encontré información sobre devoluciones de productos digitales en nuestra base de conocimiento. Un agente humano podrá ayudarte mejor.
                </p>
              </div>
              <button
                type="button"
                className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-700 text-sm font-medium hover:bg-slate-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#4338ca] focus-visible:ring-offset-1 transition-colors min-h-[44px]"
              >
                <Ic.Mail size={15} />
                Contactar soporte
              </button>
            </div>
          </div>
        </div>

        {/* Input */}
        <div className="border-t border-slate-100 px-4 py-3 bg-white">
          <label htmlFor="chat-input" className="block text-[11px] font-medium text-slate-500 mb-1.5">
            Escribe tu pregunta
          </label>
          <div className="flex items-center gap-2">
            <input
              id="chat-input"
              type="text"
              placeholder="¿En qué puedo ayudarte?"
              aria-describedby="chat-nota"
              readOnly
              className="flex-1 px-3 py-2 rounded-lg border border-slate-200 bg-slate-50 text-slate-700 text-sm focus:outline-none focus:ring-2 focus:ring-[#4338ca] focus:border-transparent"
            />
            <button
              type="button"
              aria-label="Enviar mensaje"
              className="w-9 h-9 rounded-lg flex items-center justify-center text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#4338ca] focus-visible:ring-offset-1 transition-opacity hover:opacity-90"
              style={{ background: 'var(--acento)' }}
            >
              <Ic.Send size={16} />
            </button>
          </div>
          <p id="chat-nota" className="text-[10px] text-slate-400 mt-1.5 leading-snug">
            Las respuestas se generan a partir de la base de conocimiento. Pueden contener errores.
          </p>
        </div>
      </div>

      <A11yAnnotationPanel items={CHAT_ANNOTATIONS} />
    </>
  )
}

// ═══════════════════════════════════════════════════════════
// PANTALLA 4 — PANEL INTERNO
// ═══════════════════════════════════════════════════════════

const KCS_ROWS: {
  pregunta: string
  veces: number
  similitud: number
  fecha: string
  estado: KcsStatus
}[] = [
  { pregunta: '¿Cómo cambio mi contraseña desde la app móvil?', veces: 47, similitud: 0.92, fecha: '15/07/2026', estado: 'nueva' },
  { pregunta: '¿Cuánto tarda el reembolso tras una devolución aprobada?', veces: 38, similitud: 0.76, fecha: '18/07/2026', estado: 'revision' },
  { pregunta: '¿Puedo tener dos cuentas con el mismo correo?', veces: 29, similitud: 0.88, fecha: '20/07/2026', estado: 'cubierta' },
  { pregunta: '¿Cómo exporto mi historial de pedidos en PDF?', veces: 24, similitud: 0.41, fecha: '21/07/2026', estado: 'nueva' },
  { pregunta: '¿Se puede cambiar la dirección de envío tras confirmar?', veces: 19, similitud: 0.65, fecha: '22/07/2026', estado: 'revision' },
  { pregunta: '¿Qué ocurre si mi paquete llega dañado?', veces: 15, similitud: 0.53, fecha: '24/07/2026', estado: 'nueva' },
]

const PANEL_ANNOTATIONS = [
  { n: 1, text: 'Tabla con role="table" implícito (<table>). Encabezados <th scope="col"> para asociación correcta con celdas. Datos numéricos en celdas <td>.' },
  { n: 2, text: 'Chips KCS: siempre comunican estado con ícono + texto. El color es indicativo, nunca el único canal de información (cumple WCAG 1.4.1).' },
  { n: 3, text: 'Botón "Crear artículo": aria-label incluye la pregunta específica para dar contexto ("Crear artículo para: ¿Cómo cambio mi contraseña…?").' },
  { n: 4, text: 'Métricas: valores numéricos con <abbr> o texto completo en aria-label para evitar ambigüedad (ej. "72 % de respuestas con cita").' },
  { n: 5, text: 'Jerarquía de encabezados: H1 "Panel interno · Preguntas sin resolver" → H2 "Métricas del ciclo KCS" → encabezados de tabla implícitos en <th>.' },
  { n: 6, text: 'Contraste de tabla: filas alternas bg-slate-50 (#F8FAFC) vs blanco no tienen diferencia de contraste suficiente para ser el único diferenciador; el borde de celda complementa la separación visual.' },
]

function PanelScreen() {
  return (
    <main id="main-content" tabIndex={-1} className="focus:outline-none">
      {/* ── Header ─────────────────────────────────── */}
      <div className="border-b border-slate-200 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6 flex items-start justify-between gap-4 flex-wrap">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-indigo-600 uppercase tracking-widest mb-1">
              <Ic.BarChart size={14} />
              Panel interno
            </div>
            <h1 className="text-2xl font-bold text-slate-900" style={{ fontFamily: "'DM Serif Display', serif" }}>
              Preguntas sin resolver
            </h1>
            <p className="text-slate-500 text-sm mt-1">Ciclo KCS — candidatos a nuevo artículo de conocimiento</p>
          </div>
          <div className="text-xs text-slate-400 bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 self-start">
            Última actualización: hoy, 09:41 h
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8 space-y-8">
        {/* ── Metrics ────────────────────────────────── */}
        <section aria-labelledby="metrics-h2">
          <h2 id="metrics-h2" className="sr-only">Métricas del ciclo KCS</h2>
          <dl className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {[
              {
                term: 'Preguntas sin resolver',
                value: '34',
                sub: '+5 esta semana',
                icon: <Ic.HelpCircle size={22} className="text-indigo-600" />,
                bg: 'bg-indigo-50',
                trend: 'up',
              },
              {
                term: 'Respuestas con cita',
                value: '72 %',
                sub: 'de las últimas 500',
                icon: <Ic.CheckCircle size={22} className="text-emerald-600" />,
                bg: 'bg-emerald-50',
                trend: 'good',
              },
              {
                term: 'Artículos creados desde preguntas',
                value: '18',
                sub: 'este mes (ciclo KCS)',
                icon: <Ic.FileText size={22} className="text-purple-600" />,
                bg: 'bg-purple-50',
                trend: 'neutral',
              },
            ].map(({ term, value, sub, icon, bg }) => (
              <div key={term} className="bg-white border border-slate-200 rounded-2xl p-5 flex items-start gap-4">
                <div className={`shrink-0 w-12 h-12 rounded-xl flex items-center justify-center ${bg}`}>
                  {icon}
                </div>
                <div>
                  <dt className="text-xs font-semibold text-slate-500 uppercase tracking-wide leading-snug">{term}</dt>
                  <dd className="text-3xl font-bold text-slate-900 mt-1 leading-none" aria-label={`${value} ${term}`}>
                    {value}
                  </dd>
                  <p className="text-xs text-slate-400 mt-1">{sub}</p>
                </div>
              </div>
            ))}
          </dl>
        </section>

        {/* ── Filters bar ────────────────────────────── */}
        <div className="flex items-center gap-3 flex-wrap">
          <span className="text-sm font-medium text-slate-600">Filtrar por estado:</span>
          {(['todas', 'nueva', 'revision', 'cubierta'] as const).map((s, i) => (
            <button
              key={s}
              type="button"
              className={`px-3 py-1.5 rounded-full text-xs font-semibold border transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#4338ca] focus-visible:ring-offset-1 min-h-[36px] ${
                i === 0
                  ? 'bg-indigo-700 text-white border-indigo-700'
                  : 'bg-white text-slate-600 border-slate-200 hover:border-indigo-300 hover:text-indigo-700'
              }`}
              aria-pressed={i === 0}
            >
              {s === 'todas' ? 'Todas' : s === 'revision' ? 'En revisión' : s.charAt(0).toUpperCase() + s.slice(1)}
            </button>
          ))}
        </div>

        {/* ── Table ──────────────────────────────────── */}
        <section aria-labelledby="table-h2">
          <h2 id="table-h2" className="sr-only">Tabla de preguntas sin resolver</h2>
          <div className="rounded-2xl border border-slate-200 overflow-hidden bg-white">
            <div className="overflow-x-auto">
              <table className="w-full text-sm" aria-label="Preguntas sin resolver — ciclo KCS">
                <thead>
                  <tr className="border-b border-slate-100 bg-slate-50">
                    {[
                      { label: 'Pregunta', align: 'text-left' },
                      { label: 'Veces preguntada', align: 'text-right' },
                      { label: 'Similitud máx.', align: 'text-right' },
                      { label: 'Fecha', align: 'text-left' },
                      { label: 'Estado', align: 'text-left' },
                      { label: 'Acción', align: 'text-left' },
                    ].map(({ label, align }) => (
                      <th
                        key={label}
                        scope="col"
                        className={`px-4 py-3 text-xs font-bold text-slate-500 uppercase tracking-wider whitespace-nowrap ${align}`}
                      >
                        {label}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {KCS_ROWS.map((row, i) => (
                    <tr
                      key={i}
                      className={`hover:bg-slate-50 transition-colors ${i % 2 === 1 ? 'bg-slate-50/50' : 'bg-white'}`}
                    >
                      <td className="px-4 py-3.5 text-slate-800 font-medium max-w-[280px]">
                        <span className="line-clamp-2 leading-snug">{row.pregunta}</span>
                      </td>
                      <td className="px-4 py-3.5 text-right tabular-nums">
                        <span className="font-semibold text-slate-900">{row.veces}</span>
                      </td>
                      <td className="px-4 py-3.5 text-right tabular-nums">
                        <span
                          className={`font-semibold ${
                            row.similitud >= 0.8
                              ? 'text-emerald-700'
                              : row.similitud >= 0.6
                                ? 'text-amber-700'
                                : 'text-slate-500'
                          }`}
                          aria-label={`Similitud ${Math.round(row.similitud * 100)} por ciento`}
                        >
                          {Math.round(row.similitud * 100)} %
                        </span>
                      </td>
                      <td className="px-4 py-3.5 text-slate-500 whitespace-nowrap text-xs">
                        <time>{row.fecha}</time>
                      </td>
                      <td className="px-4 py-3.5">
                        <KcsChip status={row.estado} />
                      </td>
                      <td className="px-4 py-3.5">
                        {row.estado !== 'cubierta' ? (
                          <button
                            type="button"
                            aria-label={`Crear artículo para: ${row.pregunta}`}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border border-indigo-200 text-indigo-700 bg-indigo-50 hover:bg-indigo-100 hover:border-indigo-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#4338ca] focus-visible:ring-offset-1 transition-colors min-h-[36px] whitespace-nowrap"
                          >
                            <Ic.Plus size={13} />
                            Crear artículo
                          </button>
                        ) : (
                          <span className="text-xs text-slate-400 italic">Artículo existente</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="px-4 py-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-400 bg-slate-50/50">
              <span>Mostrando 6 de 34 preguntas</span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  disabled
                  aria-label="Página anterior"
                  className="px-2.5 py-1 rounded border border-slate-200 disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  ‹ Anterior
                </button>
                <span className="px-2.5 py-1 rounded bg-indigo-700 text-white font-semibold">1</span>
                <button
                  type="button"
                  aria-label="Página siguiente"
                  className="px-2.5 py-1 rounded border border-slate-200 hover:border-indigo-300 hover:text-indigo-700 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#4338ca] focus-visible:ring-offset-1"
                >
                  Siguiente ›
                </button>
              </div>
            </div>
          </div>
        </section>
      </div>

      <A11yAnnotationPanel items={PANEL_ANNOTATIONS} />
    </main>
  )
}

// ═══════════════════════════════════════════════════════════
// HEADER + FLOATING CHAT BUTTON
// ═══════════════════════════════════════════════════════════

function AppHeader({
  screen,
  onNavigate,
  showAnnotations,
  onToggleAnnotations,
}: {
  screen: Screen
  onNavigate: (s: Screen) => void
  showAnnotations: boolean
  onToggleAnnotations: () => void
}) {
  const nav: { label: string; screen: Screen }[] = [
    { label: 'Inicio', screen: 'home' },
    { label: 'Artículo', screen: 'article' },
    { label: 'Panel interno', screen: 'panel' },
  ]

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur border-b border-slate-200 supports-[backdrop-filter]:bg-white/80">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
        <button
          type="button"
          onClick={() => onNavigate('home')}
          className="focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#4338ca] focus-visible:ring-offset-2 rounded-lg"
          aria-label="Ir al inicio del centro de ayuda"
        >
          <Logo />
        </button>

        <div className="flex items-center gap-1">
          <nav aria-label="Pantallas del prototipo">
            <ul className="flex items-center gap-0.5 list-none p-0 m-0">
              {nav.map(({ label, screen: s }) => (
                <li key={s}>
                  <button
                    type="button"
                    onClick={() => onNavigate(s)}
                    aria-current={screen === s ? 'page' : undefined}
                    className={`px-3 py-2 rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#4338ca] focus-visible:ring-offset-1 min-h-[40px] ${
                      screen === s
                        ? 'bg-indigo-50 text-indigo-700'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                    }`}
                  >
                    {label}
                  </button>
                </li>
              ))}
            </ul>
          </nav>

          <button
            type="button"
            onClick={onToggleAnnotations}
            aria-pressed={showAnnotations}
            className={`ml-2 inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-semibold border transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#4338ca] focus-visible:ring-offset-1 min-h-[36px] ${
              showAnnotations
                ? 'bg-amber-100 text-amber-800 border-amber-300'
                : 'bg-white text-slate-500 border-slate-200 hover:border-amber-300 hover:text-amber-700'
            }`}
            title={showAnnotations ? 'Ocultar anotaciones a11y' : 'Mostrar anotaciones a11y'}
          >
            <Ic.Eye size={13} />
            A11y
          </button>
        </div>
      </div>
    </header>
  )
}

// ═══════════════════════════════════════════════════════════
// ROOT APP
// ═══════════════════════════════════════════════════════════

export default function App() {
  const [screen, setScreen] = useState<Screen>('home')
  const [chatOpen, setChatOpen] = useState(false)
  const [showAnnotations, setShowAnnotations] = useState(true)
  const mainRef = useRef<HTMLDivElement>(null)

  // Focus main content on screen change for keyboard/SR users
  useEffect(() => {
    const el = document.getElementById('main-content')
    if (el) el.focus()
  }, [screen])

  const navigate = (s: Screen) => {
    setScreen(s)
    setChatOpen(false)
  }

  return (
    <div ref={mainRef} className="min-h-screen bg-slate-50">
      <SkipLink />
      <AppHeader
        screen={screen}
        onNavigate={navigate}
        showAnnotations={showAnnotations}
        onToggleAnnotations={() => setShowAnnotations(v => !v)}
      />

      {/* ── Screen rendering ──────────────────────── */}
      <div className={showAnnotations ? '' : '[&_.border-t-2.border-amber-300]:hidden'}>
        {screen === 'home' && (
          <HomeScreen
            onArticle={() => navigate('article')}
            onChat={() => setChatOpen(true)}
          />
        )}
        {screen === 'article' && <ArticleScreen onHome={() => navigate('home')} />}
        {screen === 'panel' && <PanelScreen />}
      </div>

      {/* ── Chat Widget (any screen) ──────────────── */}
      {chatOpen && <ChatWidget onClose={() => setChatOpen(false)} />}

      {/* ── Floating Chat Button ──────────────────── */}
      {!chatOpen && (
        <button
          type="button"
          onClick={() => setChatOpen(true)}
          aria-label="Abrir asistente virtual"
          aria-haspopup="dialog"
          className="fixed bottom-6 right-6 z-30 w-14 h-14 rounded-2xl text-white shadow-lg shadow-indigo-500/30 flex items-center justify-center hover:opacity-90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-offset-4 focus-visible:ring-offset-[#4338ca] transition-all active:scale-95"
          style={{ background: 'var(--acento)' }}
        >
          <Ic.MessageCircle size={24} />
        </button>
      )}
    </div>
  )
}
